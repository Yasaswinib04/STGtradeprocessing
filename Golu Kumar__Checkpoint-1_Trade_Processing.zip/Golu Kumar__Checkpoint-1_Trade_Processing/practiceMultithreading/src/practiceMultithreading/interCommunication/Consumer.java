package practiceMultithreading.interCommunication;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.ArrayBlockingQueue;

public class Consumer implements Runnable{
	
	protected ArrayBlockingQueue<String> queue=null;
	
	public Consumer(ArrayBlockingQueue<String> queue)  {
	   
		this.queue=queue;
		
		Thread t=new Thread(this,"Consumer");
		t.start();
		
//		System.out.println("Consumer thread has been started");
	}
	
	
	public void consume() throws IOException {
		
		FileWriter writer=new FileWriter("output.txt")	;
		PrintWriter outputStream=new PrintWriter(writer);	
		
       try {
			
			int i=1;
			int count=0;
			while(i<=100) {
				
				try {
					
					String s=queue.take();
					System.out.println("printing trade data");
                    String[] splitted=s.split("\\s+");
                    
                    
                    
				   outputStream.println("Modified-tradeId: "+splitted[0]+"   Modified-tradeType: "+splitted[1]);
				   count++;
				   if(count==10) {
					   outputStream.println(Integer.toString(count));
					   count=0;
				   }
			
				}
				catch(Exception e) { System.out.println("error is here"); }
				
				try {
					Thread.sleep(200);
				}catch(Exception e) {
					System.out.println(e);
				}
				
				i++;
				
			}
			
			outputStream.close();
			
		}catch(Exception e) {
			System.out.println(e);
		}	
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		try {
			consume();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     
	} 

}
