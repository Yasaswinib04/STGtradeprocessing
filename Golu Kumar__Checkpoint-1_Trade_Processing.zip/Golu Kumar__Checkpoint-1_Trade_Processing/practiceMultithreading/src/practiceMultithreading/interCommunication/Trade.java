package practiceMultithreading.interCommunication;

public class Trade {

	private String tradeId;
	private String tradeType;
	
	
	public Trade() {
		//super();
	}
	public Trade(String tradeId, String tradeType) {
		//super();
		this.tradeId = tradeId;
		this.tradeType = tradeType;
	}
	@Override
	public String toString() {
		return "Trade [tradeId=" + tradeId + ", tradeType=" + tradeType + "]";  
	}
	public String getTradeId() {
		return tradeId;
	}
	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}
	public String getTradeType() {
		return tradeType;
	}
	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}
	
}
