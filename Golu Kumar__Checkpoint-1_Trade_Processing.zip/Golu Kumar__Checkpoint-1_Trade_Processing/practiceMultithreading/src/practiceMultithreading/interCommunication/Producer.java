package practiceMultithreading.interCommunication;

import java.io.FileWriter; 
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.ArrayBlockingQueue;



public class Producer implements Runnable{
	
	protected ArrayBlockingQueue<String> queue=null;
	
	public Producer(ArrayBlockingQueue<String> queue) throws IOException {
		
		this.queue=queue;
		
		Thread t=new Thread(this,"Producer");
		t.start();
		
	}
	
	public void produce() {
		
      try {	
			int i=1;
			while(i<=100) {
				
				//System.out.println("i am under loop of producer thread");
				
				queue.add(Main.getAlphaNumericString(4)+" "+Main.getAlphaNumericString(6));
				
//				System.out.println("first string has been written in input.txt");
				
				try {
					Thread.sleep(200);
				}catch(Exception e) {
					System.out.println(e);
				}
				
				i++;
				
			}
			
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
		
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		produce();
	}

}
