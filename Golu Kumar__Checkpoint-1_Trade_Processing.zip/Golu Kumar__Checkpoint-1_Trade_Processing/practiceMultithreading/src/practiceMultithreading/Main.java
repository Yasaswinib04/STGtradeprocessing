package practiceMultithreading;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
         
		Runnable thread_one= new Thread_one();
		Runnable thread_two= new Thread_two();
		
		Thread thread__one=new Thread(thread_one);
		Thread thread__two=new Thread(thread_two);
		
		System.out.println("main thread of package starting the thread of both thread_one and thread_two");
		
		thread__one.start();
		Thread.sleep(100);
		thread__two.start();
		
		((Thread) thread__one).join();
		((Thread) thread__two).join();
		
		System.out.println("thread_one and thread_two are joined");
	}

}
