package practiceMultithreading;

public class Thread_one implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println("starting threads of thread_one");
		
		Thread t1=new Thread(() -> {
			
		   for(int i=0;i<3;i++) {
			   System.out.println("i am t1 from Thread_one");
			   try {
				   Thread.sleep(100);
			   }catch(Exception e) {System.out.println("execption caught in sleeping");}
		   }
				
		});
		
		Thread t2=new Thread(() -> {
			
			   for(int i=0;i<3;i++) {
				   System.out.println("i am t2 from Thread_one");
				   try {
					   Thread.sleep(100);
				   }catch(Exception e) {System.out.println("execption caught in sleeping");}
			   }
					
		});
		
		t1.start();
		 try {
			   Thread.sleep(10);
		   }catch(Exception e) {System.out.println("execption caught in sleeping");}
		t2.start();
		
		
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("both threads of Thread_one have been completed");
		
		
		
		
		
		
				
				
		
		
	}

}
